

// function openNav() {
//     document.getElementById("mySidebar").style.width = "250px";
//     document.getElementById("main").style.marginLeft = "250px";
//   }
  
//   function closeNav() {
//     document.getElementById("mySidebar").style.width = "0";
//     document.getElementById("main").style.marginLeft= "0";
//   }



//   var a = document.getElementById("upload");
//   var b = document.getElementById("list-of-notice");
//   var c = document.getElementById("profile");
//   var d = document.getElementById("edit-profile");
//   function myFunction() {
//       a.style.display = "block";
//       b.style.display = "none";
//       c.style.display = "none";
//       d.style.display = "none";
//   }
//   function myFunction2() {
//       b.style.display = "block";
//       a.style.display = "none";
//       c.style.display = "none";
//       d.style.display = "none";
//   }
//   function myFunction3() {
//       c.style.display = "block";
//       a.style.display = "none";
//       b.style.display = "none";
//       d.style.display = "none";
//   }
//   function myFunction4() {
//       d.style.display = "block";
//       a.style.display = "none";
//       c.style.display = "none";
//       b.style.display = "none";
//   }