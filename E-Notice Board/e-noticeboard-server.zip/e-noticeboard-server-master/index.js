const express = require('express')
const MongoClient = require('mongodb').MongoClient
const cors = require('cors')
const bodyParser = require('body-parser')
const ObjectId = require('mongodb').ObjectId
require('dotenv').config()

const app = express()

app.use(cors())
app.use(express.json())
const port = 8080

const uri = `mongodb+srv://${process.env.DB_USER}:${process.env.DB_PASS}@cluster0.llav3.mongodb.net/?retryWrites=true&w=majority`

const client = new MongoClient(uri, {
  useNewUrlParser: true,
  useUnifiedTopology: true
})
client.connect(err => {
  const collection = client.db('enoticeboard').collection('enotices')
  const imageCollection = client.db('enoticeboard').collection('images')
  const officeCollection = client.db('enoticeboard').collection('offices')

  app.get('/notices', (req, res) => {
    collection
      .find()
      .sort({ _id: -1 })
      .limit(5)
      .toArray((err, items) => {
        if (err) {
          console.error(err)
          res.status(500).send('Error fetching items from the database.')
          return
        }

        res.send(items)
      })
  })

  app.get('/allNotice', (req, res) => {
    collection.find().toArray((err, items) => {
      res.send(items)
    })
  })

  app.get('/getImage', (req, res) => {
    imageCollection.find().toArray((err, items) => {
      res.send(items)
    })
  })

  app.get('/getInfo', (req, res) => {
    officeCollection.find().toArray((err, items) => {
      res.send(items)
    })
  })

  app.put('/update/:id', async (req, res) => {
    const { id } = req.params
    const { email, name1, number1, name2, number2 } = req.body

    try {
      const result = await officeCollection.updateOne(
        { _id: ObjectId(id) },
        { $set: { email, name1, number1, name2, number2 } }
      )

      res.json(result)
    } catch (error) {
      console.error(error)
      res.status(500).json({ error: 'An error occurred' })
    }
  })

  app.get('/office/:id', async (req, res) => {
    const id = req.params.id
    const query = { _id: ObjectId(id) }
    const officeInfo = await officeCollection.findOne(query)
    res.send(officeInfo)
  })

  app.post('/addProduct', (req, res) => {
    const newEvent = req.body

    collection.insertOne(newEvent).then(result => {
      res.send(result.insertedCount > 0)
    })
  })

  app.post('/addImage', (req, res) => {
    const newEvent = req.body

    imageCollection.insertOne(newEvent).then(result => {
      res.send(result.insertedCount > 0)
    })
  })

  app.post('/officeInfo', (req, res) => {
    const newEvent = req.body

    officeCollection.insertOne(newEvent).then(result => {
      res.send(result.insertedCount > 0)
    })
  })

  app.delete('/delete/:id', (req, res) => {
    collection.deleteOne({ _id: ObjectId(req.params.id) }).then(result => {
      res.send(result.deletedCount > 0)
    })
  })

  app.delete('/deleteImage/:id', (req, res) => {
    imageCollection.deleteOne({ _id: ObjectId(req.params.id) }).then(result => {
      res.send(result.deletedCount > 0)
    })
  })

  app.get('/', (req, res) => {
    res.send('E noticeboard!')
  })
  console.log('database connected')
})
//console.log
app.listen(process.env.PORT || port)
