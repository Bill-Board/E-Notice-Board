# e-noticeboard-server
#### 1. Digital platform for students, faculty, and staff.
#### 2. Access important information and announcements.
#### 3. Virtual bulletin board for upcoming events, course updates, and policies.
#### 4. Convenient and centralized way to keep everyone informed.
#### 5. Enhances communication and connection within the department.

### Live site- https://e-noticeboard-nu.vercel.app/
